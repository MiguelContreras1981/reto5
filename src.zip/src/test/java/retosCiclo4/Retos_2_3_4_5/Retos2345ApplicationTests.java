package retosCiclo4.Retos_2_3_4_5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Retos2345ApplicationTests {

	@Test
	void contextLoads() {
	}

}
